MyLifeOrganized Application
----------------------------

Thank you for downloading MyLifeOrganized application (MLO).

Web site:           http://www.mylifeorganized.net/
Facebook:           https://www.facebook.com/MyLifeOrganized
Discussion group:   https://groups.google.com/forum/#!forum/MyLifeOrganized
Reviews:            http://www.mylifeorganized.net/testimonials.shtml
E-mail:	            info@mylifeorganized.net



What is MyLifeOrganized?
-------------------------

MyLifeOrganized is a simple yet powerful personal time and task management 
software application. Use built-in outliner to organize your 
goals, projects and tasks into a tree and MyLifeOrganized will generate a simple
to-do list of actions for you. This list will contain only those actions 
which require immediate attention and will be sorted in order of priority 
so that you can stay focused on what is really important to you. The mobile editions
of MyLifeOrganized can be synced with desktop editon. MyLifeOrganized 
can also be synced with your MS Outlook. Simply minimize MLO to your system tray 
where it is available for your next thought or task.

Please visit http://www.mylifeorganized.net for more details.
Join MLO community at:   https://groups.google.com/forum/#!forum/MyLifeOrganized


How to install
--------------
1. If you downloaded MLO installer "MLO-Setup.exe" just run it and follow the instructions.
   Previous MLO versions will be updated automatically (no uninstall needed)
2. If you downloaded zip file: "mlo.zip" then no installation needed. Just unzip files 
   to a folder of your choice and run the application mlo.exe. 


How to uninstall
----------------
1. If you used MLO installer to install the program use "Add or Remove Programs" from your Windows Control Panel 
   to completely uninstall MLO.
2. If you used zip archive to install MLO, simply delete all the files from the folder you copied the application to.


Files
-----
mlo.exe				- MyLifeOrganized application
mlo.chm				- Help documentation
MLOWiFiSync.dll                 - MLO WiFi sync module (optional). Used to sync with MyLifeOrganized on mobile devices using WiFi

Templates\*.mlt			- MLO templates
Reports\*.*			- MLO print report templates
Reports\PocketMod\*.*          	- MLO PocketMod report templates
Sound\*.*			- MLO reminders sound files
Themes\*.mlthm                  - MLO themes


LICENSE
-------
There are two versions of MyLifeOrganized application: 

1) Free 45-day Trial Version 
2) Registered version (Standard Edition or Professional Edition). 

You can find out what version you have by checking the About window 
at Help->About menu.

MyLifeOrganized trial version is a commercial application. You can use it
free of charge for evaluation purposes for no more then 45 days. After that
you  need  to  register  your  copy.  Please read license.txt for licensing
terms.


Distribution
------------
You can freely distribute this archive.
Please inform us via e-mail ( info@mylifeorganized.net ) about that.


MyLifeOrganized - Change Log
-----------------------------
The complete change log can be found on our website:
http://www.mylifeorganized.net/change-log.shtml




--------------
Thanks to Mark James for his Silk icon set we used in MyLifeOrganized application: 
http://www.famfamfam.com/lab/icons/silk/

Thanks to Roy Magne Klever for Smart components we used in MyLifeOrganized application:
http://rmklever.com
