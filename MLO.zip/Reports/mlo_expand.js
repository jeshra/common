//Unhide all
function UnhideAll(){

  var x = document.getElementsByTagName('span');
  for (var i=0;i<x.length;i++)
  {
  // alert(i);
   if (x[i].getAttribute('state')) 
   {
  //   alert('Found!')
     x[i].className = 'visible';
   }  
  }   
}

//hide all
function hideAll(){

  var x = document.getElementsByTagName('span');
  for (var i=0;i<x.length;i++)
  {
  // alert(i);
   if (x[i].getAttribute('state')) 
   {
  //   alert('Found!')
     x[i].className = 'hidden';
   }  
  }   
}


function mousedown2() {

  var PressId = this.getAttribute('connected');
//  alert(PressId);
  var pressControl = document.getElementById(PressId);
  var state = pressControl.state;
//  alert(state);
  state = (state=='hidden') || (!state) ? 'visible' : 'hidden';
//  alert(state);  
  pressControl.className = state;
  pressControl.state = state; 

}

function doOnLoad() {

// connecting the links to their hidden brothers

var x = document.getElementsByTagName('span');
for (var i=0;i<x.length;i++)
{
// alert(i);
 if (x[i].getAttribute('connected')) 
 {
//   alert('Found!')
   x[i].onclick = mousedown2;
 }  
}

// hiding what should be hidden

var x = document.getElementsByTagName('span');
for (var i=0;i<x.length;i++)
{
// alert(i);
 if (x[i].getAttribute('state')) 
 {
//   alert('Found!')
   x[i].className = 'hidden';
 }  
}

}


function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      oldonload();
      func();
    }
  }
}

addLoadEvent(doOnLoad);

